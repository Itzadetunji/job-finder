<!-- ========================= FOOTER ========================= -->
	<footer class="section-footer bg-dark white">
		<div class="container">
			<section class="footer-bottom">
				<p class="text-center">Copyright &copy 2018 Finder</p>
			</section>
		</div>
	</footer>
	<!-- ========================= FOOTER END // ========================= -->

	<?php include ('includes/scripts.php'); ?>
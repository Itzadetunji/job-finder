<?php
	$http_base = "http://";
	$http_host = $_SERVER['HTTP_HOST'];

	$domain = "$http_base$http_host/proj";
?>
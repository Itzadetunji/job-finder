	<script type="text/javascript">
		/// some script

		// jquery ready start
		$(document).ready(function() {
			// jQuery code

		});
		// jquery end
	</script>
	
	<!-- jQuery -->
	<script src="js/jquery-2.0.0.min.js" type="text/javascript"></script>
	<!-- Bootstrap4 files-->
	<script src="js/bootstrap.bundle.min.js" type="text/javascript"></script>
	<!-- custom javascript -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<script src="js/script.js" type="text/javascript"></script>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Eniola Osabiya">

	<title><?php echo $head_title ?></title>

	<link rel="shortcut icon" type="image/x-icon" href="logos/favicon.ico">

	<!-- Main CSS -->
	<link href="css/main.css" rel="stylesheet" type="text/css"/>
	<link href="css/responsive.css" rel="stylesheet" media="only screen and (max-width: 1200px)"/>
</head>